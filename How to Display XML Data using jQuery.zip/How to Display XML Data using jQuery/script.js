$(document).ready(function(){
	
	let xml = 
	"<?xml version='1.0' ?>"
	+ "<doc>"
	+"		<member>"
	+"			<firstname>John</firstname>"
	+"			<lastname>Smith</lastname>"
	+"			<age>21</age>"
	+"		</member>"
	+"		<member>"
	+"			<firstname>Steve</firstname>"
	+"			<lastname>Roger</lastname>"
	+"			<age>25</age>"
	+"		</member>"
	+"		<member>"
	+"			<firstname>Natasha</firstname>"
	+"			<lastname>Romanof</lastname>"
	+"			<age>19</age>"
	+"		</member>"
	+"		<member>"
	+"			<firstname>Yor</firstname>"
	+"			<lastname>Forger</lastname>"
	+"			<age>26</age>"
	+"		</member>"
	+"		<member>"
	+"			<firstname>Tony</firstname>"
	+"			<lastname>Stark</lastname>"
	+"			<age>35</age>"
	+"		</member>"
	+"	</doc>";
	
	
	$('#display').on('click', function(){
		let data = $.parseXML(xml); 
	
		let $xml = $(data);
	
		let $member = $xml.find("member");
	
		let content = "";
		$member.each(function(){
		
			let firstname = $(this).find('firstname').text();
			let lastname = $(this).find('lastname').text();
			let age = $(this).find('age').text();
			
			content += "<tr>"
				+ "<td>"+firstname+"</td>"
				+ "<td>"+lastname+"</td>"
				+ "<td>"+age+"</td>"
				+ "</tr>";
			
			$("#result" ).html(content);
		
		});
	});
	
	
});